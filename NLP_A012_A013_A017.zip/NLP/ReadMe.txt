NATURAL LANGUAGE PROCESSING

Automated Content Creation and Personalization
for E-commerce Product Descriptions

Presented By:
Sancia Fernandes (A012) | Yash Dudeja (A013) | Sherin Ouseph (A017)

1. Attaching Project Datasets and Report along with Task Report
2. All the Reports contain their specific colab code


3. with that attaching folder named "Streamlit Datasets" as the project code file takes 45 min using GPU on the training data as dataset is large,
   please use upload those datasets directly to run the streamlit part so you dont need to run the whole code.

Thanks & Regards 
